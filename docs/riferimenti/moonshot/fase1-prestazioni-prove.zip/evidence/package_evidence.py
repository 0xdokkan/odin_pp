#!/usr/bin/env python3
import datetime,hashlib,json,zipfile
from pathlib import Path
root=Path("build/moonshot/cardboard-performance")
docs=Path("docs/riferimenti/moonshot")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((root/"before/source-manifest.json").read_text())["sources"]
current=json.loads((root/"candidate-c/source-manifest.json").read_text())
current["tools/moonshot/README.md"]=sha(Path("tools/moonshot/README.md"))
for p,h in current.items(): assert sha(Path(p))==h,p
changed={p:h for p,h in current.items() if base.get(p)!=h}
assert not set(base)-set(current)
manifest=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit="ddc6b186942d4c78597dc0f3f06c1a73483b716e",baseline_archive="fase1-cartoncino-capacita-prove.zip",baseline_archive_sha256=sha(docs/"fase1-cartoncino-capacita-prove.zip"),sources=current,delta=changed,binaries={},captures={},evidence={})
for v,binary in [("before","page-cardboard-final-benchmark"),("before","odin-page-cardboard-speed"),("candidate-c","page-cardboard-benchmark"),("candidate-c","odin-page-cardboard-play")]:
 p=root/v/binary;manifest["binaries"][str(p)]=sha(p)
for v,folder in [("before","speed-gallery"),("candidate-c","gallery")]:
 for p in sorted((root/v/folder/"captures").glob("*.png")):manifest["captures"][str(p)]=sha(p)
artifacts=[]
for p in sorted(root.rglob("*")):
 if not p.is_file() or "reference" in p.parts or "gallery" in str(p) or "candidate-a-source" in p.parts or "candidate-b-source" in p.parts:continue
 if p.suffix in (".log",".json",".csv",".stderr",".py",".md"):artifacts.append(p)
for p in artifacts:manifest["evidence"][str(p)]=sha(p)
manifest_path=docs/"fase1-prestazioni-manifest.json"
manifest_path.write_text(json.dumps(manifest,indent=2)+"\n")
selected=("odin_pp_page_cardboard_01_piede.png","odin_pp_page_cardboard_06_salita_dettaglio.png","odin_pp_page_cardboard_08_morte_piega.png","odin_pp_page_cardboard_23_retro_cartoncino.png","odin_pp_page_cardboard_24_laboratorio.png")
archive=docs/"fase1-prestazioni-prove.zip"
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write(manifest_path,"manifest.json")
 for p in changed:z.write(p,"delta/"+p)
 for p in artifacts:z.write(p,"evidence/"+str(p.relative_to(root)))
 for snapshot in ("candidate-a-source","candidate-b-source"):
  for p in sorted((root/snapshot).rglob("*.odin")):z.write(p,"evidence/"+str(p.relative_to(root)))
 for v,folder in [("candidate-c","gallery")]:
  for name in selected:
   p=root/v/folder/"captures"/name;z.write(p,"captures/"+v+"/"+name)
 z.writestr("LEGGIMI.txt","Variante finale C. Base: archivio fase1-cartoncino-capacita-prove.zip, SHA nel manifest. Estrarre source/ della base in un checkout con gli assets originali, sovrascrivere i file di delta/. Nessuna cancellazione sorgenti. Comandi, hash e exit code in evidence/. Binari non inclusi. Immagini native finali selezionate, senza duplicare i pixel identici della baseline; manifest con tutti61PNG per versione e hash RGBA decodificati in pixels-c.json. Le serie A e B e i tentativi falliti restano distinguibili dalle sei corse C complete. Non usare i tempi dello smoke come benchmark.\n")
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),delta_files=len(changed)),indent=2))
