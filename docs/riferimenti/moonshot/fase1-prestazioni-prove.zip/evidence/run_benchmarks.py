#!/usr/bin/env python3
import datetime,hashlib,json,subprocess,time
from pathlib import Path
root=Path("build/moonshot/cardboard-performance")
records=[]
for variant,rep in [("before",1),("after",1),("after",2),("before",2),("before",3),("after",3)]:
    folder=root/variant
    binary=folder/("page-cardboard-final-benchmark" if variant=="before" else "page-cardboard-benchmark")
    log=folder/f"paired-r{rep}.log"
    assert not log.exists(),log
    cmd=["/usr/bin/time","-l",str(binary)]
    start=time.monotonic()
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open("w") as output:
        result=subprocess.run(cmd,stdout=output,stderr=subprocess.STDOUT)
    record=dict(variant=variant,replica=rep,command=cmd,started_utc=utc,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    records.append(record)
    (root/"paired-processes.json").write_text(json.dumps(records,indent=2)+"\n")
    print(record,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
for variant in ("before","after"):
    folder=root/variant
    subprocess.run(["python3","tools/moonshot/summarize_page_lab.py",*[str(folder/f"paired-r{r}.log") for r in range(1,4)],"--output-dir",str(folder/"paired-summary")],check=True)
