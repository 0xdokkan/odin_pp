# Laboratorio pagina: misure verificate

Ogni replica valida contiene quattro atti, ciascuno con 60 frame di riscaldamento esclusi e 600 misurati. Mediana e percentili sono calcolati sui singoli campioni di ciascun atto; p95/p99 usano il rango superiore (nearest rank).

I tempi sono in millisecondi. Frame è il tempo del fotogramma raylib; update e draw sono misure CPU interne al frame. Gli scope sono annidati e non sommabili. Draw misura la preparazione/invio dei comandi, non un timer GPU.

La completezza riguarda il protocollo presente nel log, non certifica l'exit code del processo, l'ottimizzazione della build o il sistema usato. Le repliche incomplete restano elencate e non contribuiscono a statistiche.

## Replica 1

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/c2-r1.log`

SHA-256: `e5c1d8ef1b328151c122b8a2c577fbfb740d9260da112b020d627542694e9087`

Esito protocollo: **completo**.

RSS massima del processo: 134.891 MiB (141443072 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.865354 | 10.415458 | 15.614834 | 17.584583 | 18.371083 |
| Still | update | 600 | 0.016938 | 0.018250 | 0.029667 | 0.034500 | 0.044708 |
| Still | draw | 600 | 9.273125 | 8.969285 | 11.390500 | 14.721750 | 14.857125 |
| Walk | frame | 600 | 12.750042 | 13.998397 | 17.453875 | 27.497416 | 33.443999 |
| Walk | update | 600 | 4.036250 | 4.247720 | 4.709167 | 9.414834 | 9.673458 |
| Walk | draw | 600 | 7.463375 | 7.634382 | 8.529292 | 16.688458 | 17.715167 |
| Climb | frame | 600 | 16.646563 | 16.670545 | 17.924083 | 18.788958 | 19.271875 |
| Climb | update | 600 | 3.714500 | 3.697126 | 3.823625 | 3.896458 | 4.065708 |
| Climb | draw | 600 | 12.285583 | 12.001376 | 12.640042 | 12.721625 | 13.003166 |
| Flight | frame | 600 | 10.141562 | 11.408980 | 14.887500 | 16.020833 | 17.673083 |
| Flight | update | 600 | 3.376688 | 3.462363 | 3.824500 | 3.911167 | 4.220042 |
| Flight | draw | 600 | 6.161666 | 6.327434 | 6.982375 | 7.163000 | 7.351167 |

## Replica 2

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/c2-r2.log`

SHA-256: `5f0b678fb8e17e39fc9c2946bc2b43f25d709644c29d4ba3c12751414b869a04`

Esito protocollo: **completo**.

RSS massima del processo: 138.734 MiB (145473536 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.408417 | 9.958326 | 14.254167 | 15.197083 | 17.671417 |
| Still | update | 600 | 0.016563 | 0.017743 | 0.027750 | 0.032208 | 0.035084 |
| Still | draw | 600 | 8.284750 | 8.636167 | 9.574583 | 11.478666 | 11.691250 |
| Walk | frame | 600 | 12.268625 | 13.449242 | 16.642749 | 17.650625 | 18.672749 |
| Walk | update | 600 | 4.024625 | 4.075360 | 4.514875 | 4.578958 | 4.700708 |
| Walk | draw | 600 | 7.476938 | 7.379569 | 7.987042 | 8.633334 | 8.685042 |
| Climb | frame | 600 | 16.667750 | 16.677784 | 18.196041 | 18.839292 | 19.779749 |
| Climb | update | 600 | 3.725313 | 3.709066 | 3.835791 | 3.938584 | 4.010334 |
| Climb | draw | 600 | 12.329042 | 12.066551 | 12.720875 | 12.842500 | 13.497000 |
| Flight | frame | 600 | 11.329333 | 12.000259 | 15.852625 | 16.692042 | 20.765333 |
| Flight | update | 600 | 3.756583 | 3.647426 | 3.888792 | 4.310958 | 4.365334 |
| Flight | draw | 600 | 6.966604 | 6.730581 | 7.115542 | 8.007333 | 8.154250 |

## Replica 3

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/c2-r3.log`

SHA-256: `7b6c6cd1f517c6c22ebc3d24b2bbb06bb26eac0b24bde2aeada20a863af523eb`

Esito protocollo: **completo**.

RSS massima del processo: 138.031 MiB (144736256 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.930646 | 10.684158 | 15.063375 | 16.497917 | 19.949041 |
| Still | update | 600 | 0.017896 | 0.019202 | 0.030334 | 0.035416 | 0.040417 |
| Still | draw | 600 | 9.352500 | 9.168958 | 11.398125 | 11.661959 | 14.799292 |
| Walk | frame | 600 | 12.308271 | 13.387986 | 16.628042 | 17.429167 | 18.530667 |
| Walk | update | 600 | 4.026333 | 4.093783 | 4.536791 | 4.583250 | 4.696917 |
| Walk | draw | 600 | 7.440208 | 7.354292 | 8.222417 | 8.594416 | 8.667458 |
| Climb | frame | 600 | 16.655583 | 16.668140 | 17.808333 | 18.815750 | 19.808292 |
| Climb | update | 600 | 3.726500 | 3.709826 | 3.836666 | 3.902250 | 4.038750 |
| Climb | draw | 600 | 12.273896 | 12.000055 | 12.627417 | 12.705084 | 12.748292 |
| Flight | frame | 600 | 11.224667 | 11.799832 | 15.648542 | 16.647791 | 17.943375 |
| Flight | update | 600 | 3.723813 | 3.613954 | 3.917916 | 4.373041 | 4.424708 |
| Flight | draw | 600 | 6.858916 | 6.597147 | 7.058583 | 8.042625 | 8.129333 |
