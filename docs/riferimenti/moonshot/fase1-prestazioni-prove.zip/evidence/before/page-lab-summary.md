# Laboratorio pagina: misure verificate

Ogni replica valida contiene quattro atti, ciascuno con 60 frame di riscaldamento esclusi e 600 misurati. Mediana e percentili sono calcolati sui singoli campioni di ciascun atto; p95/p99 usano il rango superiore (nearest rank).

I tempi sono in millisecondi. Frame è il tempo del fotogramma raylib; update e draw sono misure CPU interne al frame. Gli scope sono annidati e non sommabili. Draw misura la preparazione/invio dei comandi, non un timer GPU.

La completezza riguarda il protocollo presente nel log, non certifica l'exit code del processo, l'ottimizzazione della build o il sistema usato. Le repliche incomplete restano elencate e non contribuiscono a statistiche.

## Replica 1

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/bench-r1.log`

SHA-256: `e316b10961d8aaaf9d3752ef99b1061dd808ea62a1e8d9997c5415d734c3da00`

Esito protocollo: **completo**.

RSS massima del processo: 136.156 MiB (142770176 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.838167 | 10.588075 | 16.267750 | 17.538000 | 21.561792 |
| Still | update | 600 | 0.016813 | 0.019680 | 0.034541 | 0.047250 | 0.073917 |
| Still | draw | 600 | 9.198334 | 9.152064 | 12.506292 | 15.344125 | 16.019583 |
| Walk | frame | 600 | 12.577625 | 13.641725 | 17.105125 | 17.943375 | 18.415876 |
| Walk | update | 600 | 4.033375 | 4.143308 | 4.594583 | 5.198208 | 5.285958 |
| Walk | draw | 600 | 7.508979 | 7.471193 | 8.476791 | 9.689167 | 9.852667 |
| Climb | frame | 600 | 16.727479 | 17.115517 | 18.817957 | 29.490458 | 42.353000 |
| Climb | update | 600 | 3.740021 | 3.806381 | 4.016208 | 6.849292 | 8.916208 |
| Climb | draw | 600 | 12.347646 | 12.351583 | 12.995125 | 21.853375 | 30.427792 |
| Flight | frame | 600 | 11.311896 | 12.595845 | 18.625708 | 24.692833 | 28.328333 |
| Flight | update | 600 | 3.774145 | 3.854500 | 5.671375 | 7.825166 | 8.170625 |
| Flight | draw | 600 | 6.931000 | 7.106876 | 11.540000 | 14.498959 | 14.968291 |

## Replica 2

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/bench-r2.log`

SHA-256: `9550bd3726c7abdd87465b8c4d2becb91ee5a700d8f0058f3f59e310daca9cba`

Esito protocollo: **completo**.

RSS massima del processo: 137.141 MiB (143802368 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.887125 | 10.502192 | 15.930334 | 17.120000 | 18.882541 |
| Still | update | 600 | 0.017708 | 0.019660 | 0.031750 | 0.036333 | 0.044458 |
| Still | draw | 600 | 9.323521 | 9.018624 | 11.552833 | 14.808542 | 15.061875 |
| Walk | frame | 600 | 12.283646 | 13.446630 | 16.525500 | 17.304000 | 18.034292 |
| Walk | update | 600 | 4.030334 | 4.097737 | 4.518583 | 4.566042 | 4.676209 |
| Walk | draw | 600 | 7.446146 | 7.371695 | 7.868584 | 8.600833 | 8.742583 |
| Climb | frame | 600 | 16.691521 | 16.675382 | 17.923709 | 18.509125 | 19.738417 |
| Climb | update | 600 | 3.729063 | 3.711554 | 3.838750 | 3.890875 | 3.964250 |
| Climb | draw | 600 | 12.318104 | 12.062684 | 12.705833 | 12.800792 | 13.125459 |
| Flight | frame | 600 | 11.415083 | 12.508768 | 16.337249 | 17.355917 | 18.574333 |
| Flight | update | 600 | 3.797271 | 3.799602 | 4.351750 | 4.425250 | 4.810125 |
| Flight | draw | 600 | 6.970833 | 6.964780 | 8.076250 | 8.180167 | 8.347917 |

## Replica 3

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/bench-r3.log`

SHA-256: `27c4f70236f387fcb2b3f0513f277ded0989f1d8ed5d27d46c8fa84e0ceb1a5e`

Esito protocollo: **completo**.

RSS massima del processo: 131.750 MiB (138149888 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 10.006479 | 10.438758 | 15.109042 | 16.688876 | 17.660541 |
| Still | update | 600 | 0.016896 | 0.018530 | 0.029875 | 0.034584 | 0.041583 |
| Still | draw | 600 | 8.838105 | 9.014412 | 10.388584 | 14.935458 | 15.354208 |
| Walk | frame | 600 | 13.023875 | 14.086267 | 17.170792 | 26.378334 | 33.035625 |
| Walk | update | 600 | 4.031125 | 4.220671 | 4.578375 | 9.309208 | 9.516334 |
| Walk | draw | 600 | 7.601854 | 7.731088 | 8.320208 | 15.816625 | 16.839584 |
| Climb | frame | 600 | 16.796771 | 17.149691 | 18.819541 | 32.023083 | 45.783792 |
| Climb | update | 600 | 3.731937 | 3.793289 | 3.953375 | 6.956584 | 9.002458 |
| Climb | draw | 600 | 12.456437 | 12.475776 | 13.047708 | 24.151250 | 31.525250 |
| Flight | frame | 600 | 11.400000 | 12.122967 | 16.378583 | 18.246958 | 19.957291 |
| Flight | update | 600 | 3.453666 | 3.651970 | 5.072834 | 5.181833 | 5.494042 |
| Flight | draw | 600 | 6.353187 | 6.833515 | 9.665375 | 9.983333 | 11.918458 |
