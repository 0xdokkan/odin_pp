# Laboratorio pagina: misure verificate

Ogni replica valida contiene quattro atti, ciascuno con 60 frame di riscaldamento esclusi e 600 misurati. Mediana e percentili sono calcolati sui singoli campioni di ciascun atto; p95/p99 usano il rango superiore (nearest rank).

I tempi sono in millisecondi. Frame è il tempo del fotogramma raylib; update e draw sono misure CPU interne al frame. Gli scope sono annidati e non sommabili. Draw misura la preparazione/invio dei comandi, non un timer GPU.

La completezza riguarda il protocollo presente nel log, non certifica l'exit code del processo, l'ottimizzazione della build o il sistema usato. Le repliche incomplete restano elencate e non contribuiscono a statistiche.

## Replica 1

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/final-paired-r1.log`

SHA-256: `662c8c6c0bc2d2820c21681717d83980a56dbb3b5c77b3e63f0046c789ecfd43`

Esito protocollo: **completo**.

RSS massima del processo: 141.000 MiB (147849216 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.154500 | 10.111258 | 15.033792 | 16.563667 | 17.665708 |
| Still | update | 600 | 0.016000 | 0.017239 | 0.026500 | 0.030042 | 0.035042 |
| Still | draw | 600 | 8.310604 | 8.732002 | 11.364000 | 11.708000 | 11.825500 |
| Walk | frame | 600 | 13.326229 | 13.759712 | 17.359333 | 18.600333 | 25.897166 |
| Walk | update | 600 | 4.028166 | 4.179805 | 4.629625 | 6.124167 | 6.200875 |
| Walk | draw | 600 | 7.415667 | 7.548160 | 8.727125 | 11.416666 | 11.750041 |
| Climb | frame | 600 | 16.654124 | 16.668858 | 17.973166 | 18.809916 | 19.422250 |
| Climb | update | 600 | 3.719125 | 3.702078 | 3.834209 | 3.895000 | 3.951792 |
| Climb | draw | 600 | 12.308771 | 12.023691 | 12.665959 | 12.731416 | 12.849250 |
| Flight | frame | 600 | 11.198333 | 11.687871 | 15.414917 | 16.115749 | 16.854124 |
| Flight | update | 600 | 3.519084 | 3.573729 | 3.852417 | 3.937625 | 3.998459 |
| Flight | draw | 600 | 6.445145 | 6.550621 | 7.033792 | 7.098166 | 7.189208 |

## Replica 2

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/final-paired-r2.log`

SHA-256: `c220f3bd618ed3b38a607c13fb1ad3e6da72c2a20c11862551c7b6ea9a23a58e`

Esito protocollo: **completo**.

RSS massima del processo: 139.797 MiB (146587648 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.159958 | 10.004178 | 14.897458 | 16.898833 | 18.257417 |
| Still | update | 600 | 0.016083 | 0.017116 | 0.026916 | 0.031000 | 0.032709 |
| Still | draw | 600 | 8.233355 | 8.686869 | 11.345792 | 14.543917 | 14.698084 |
| Walk | frame | 600 | 12.258437 | 13.431804 | 16.618000 | 17.566167 | 18.176334 |
| Walk | update | 600 | 4.023354 | 4.086935 | 4.509000 | 4.563209 | 4.694916 |
| Walk | draw | 600 | 7.437896 | 7.350445 | 7.908750 | 8.438916 | 8.483209 |
| Climb | frame | 600 | 16.666333 | 16.670694 | 17.851459 | 18.627042 | 18.849041 |
| Climb | update | 600 | 3.727791 | 3.708435 | 3.823458 | 3.886334 | 3.974709 |
| Climb | draw | 600 | 12.294688 | 12.017930 | 12.662208 | 12.706042 | 12.756750 |
| Flight | frame | 600 | 11.212292 | 11.643524 | 15.439333 | 16.500708 | 19.237584 |
| Flight | update | 600 | 3.461334 | 3.568602 | 3.856667 | 4.310958 | 4.397291 |
| Flight | draw | 600 | 6.210688 | 6.525209 | 7.057792 | 7.952792 | 8.099458 |

## Replica 3

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/before/final-paired-r3.log`

SHA-256: `9047512107828e379048d5819a7fd1f8a4b75ab0c1a2a76fe29927c46a7c6a0c`

Esito protocollo: **completo**.

RSS massima del processo: 140.406 MiB (147226624 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 9.650479 | 10.027897 | 14.387167 | 15.608584 | 17.456625 |
| Still | update | 600 | 0.016708 | 0.018095 | 0.028917 | 0.033208 | 0.035334 |
| Still | draw | 600 | 8.842416 | 8.746673 | 9.499500 | 11.317250 | 11.524291 |
| Walk | frame | 600 | 12.226875 | 13.369337 | 16.443666 | 17.198542 | 18.114917 |
| Walk | update | 600 | 4.023521 | 4.089164 | 4.510167 | 4.549958 | 4.657792 |
| Walk | draw | 600 | 7.457750 | 7.358320 | 7.935791 | 8.411000 | 8.508833 |
| Climb | frame | 600 | 16.632500 | 16.671168 | 17.964292 | 18.867167 | 19.301083 |
| Climb | update | 600 | 3.727375 | 3.708090 | 3.832125 | 3.874125 | 3.936250 |
| Climb | draw | 600 | 12.307958 | 12.016233 | 12.661291 | 12.727708 | 12.891208 |
| Flight | frame | 600 | 11.123208 | 11.551973 | 15.199375 | 15.906833 | 16.437626 |
| Flight | update | 600 | 3.417188 | 3.535046 | 3.855875 | 3.929042 | 3.997875 |
| Flight | draw | 600 | 6.192105 | 6.461104 | 7.005458 | 7.059917 | 7.281417 |
