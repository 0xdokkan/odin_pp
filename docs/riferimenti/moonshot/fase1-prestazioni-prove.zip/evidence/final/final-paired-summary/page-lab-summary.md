# Laboratorio pagina: misure verificate

Ogni replica valida contiene quattro atti, ciascuno con 60 frame di riscaldamento esclusi e 600 misurati. Mediana e percentili sono calcolati sui singoli campioni di ciascun atto; p95/p99 usano il rango superiore (nearest rank).

I tempi sono in millisecondi. Frame è il tempo del fotogramma raylib; update e draw sono misure CPU interne al frame. Gli scope sono annidati e non sommabili. Draw misura la preparazione/invio dei comandi, non un timer GPU.

La completezza riguarda il protocollo presente nel log, non certifica l'exit code del processo, l'ottimizzazione della build o il sistema usato. Le repliche incomplete restano elencate e non contribuiscono a statistiche.

## Replica 1

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/final/final-paired-r1.log`

SHA-256: `484631381dd0af79087d0d078ad012e7f2e0e7b210639fdc0333debf094290b5`

Esito protocollo: **completo**.

RSS massima del processo: 138.906 MiB (145653760 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.605250 | 9.919361 | 16.030833 | 17.558500 | 18.433666 |
| Still | update | 600 | 0.018875 | 0.020944 | 0.034834 | 0.039958 | 0.047541 |
| Still | draw | 600 | 8.017854 | 8.520210 | 12.398709 | 12.750625 | 13.205875 |
| Walk | frame | 600 | 11.072416 | 12.085556 | 16.382834 | 17.007999 | 19.304249 |
| Walk | update | 600 | 3.252625 | 3.324876 | 3.785292 | 5.149791 | 5.323875 |
| Walk | draw | 600 | 7.030750 | 7.042743 | 7.983250 | 10.625458 | 10.767916 |
| Climb | frame | 600 | 10.926062 | 11.833075 | 15.442000 | 16.538292 | 17.628999 |
| Climb | update | 600 | 3.108625 | 3.122318 | 3.547291 | 3.630208 | 3.718708 |
| Climb | draw | 600 | 7.174062 | 7.078421 | 8.102375 | 8.397959 | 8.480250 |
| Flight | frame | 600 | 10.627771 | 11.132241 | 14.917708 | 15.593667 | 15.823042 |
| Flight | update | 600 | 3.180688 | 3.055149 | 3.334500 | 3.398334 | 3.794209 |
| Flight | draw | 600 | 6.829521 | 6.534741 | 7.007834 | 7.091000 | 8.236458 |

## Replica 2

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/final/final-paired-r2.log`

SHA-256: `f1dd9cd97034971ceb0c79ef882e122c6f228a1fc5cb43d89854278eedb555b6`

Esito protocollo: **completo**.

RSS massima del processo: 142.484 MiB (149405696 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.593041 | 9.612948 | 14.928375 | 16.840875 | 18.032916 |
| Still | update | 600 | 0.017458 | 0.019089 | 0.030334 | 0.034791 | 0.040625 |
| Still | draw | 600 | 8.006937 | 8.307057 | 9.890584 | 12.588042 | 12.915333 |
| Walk | frame | 600 | 11.041167 | 11.834640 | 15.604958 | 16.675958 | 18.169459 |
| Walk | update | 600 | 3.260979 | 3.285861 | 3.736959 | 3.819500 | 3.880500 |
| Walk | draw | 600 | 7.076334 | 6.961837 | 7.878417 | 8.273833 | 8.407917 |
| Climb | frame | 600 | 11.379396 | 12.508911 | 17.637834 | 22.446958 | 27.886583 |
| Climb | update | 600 | 3.127395 | 3.290577 | 4.572416 | 6.312041 | 6.523792 |
| Climb | draw | 600 | 7.214229 | 7.498885 | 11.065708 | 14.681250 | 15.312041 |
| Flight | frame | 600 | 10.574896 | 11.267260 | 15.106875 | 16.359875 | 18.660709 |
| Flight | update | 600 | 3.171438 | 3.072256 | 3.373000 | 3.954167 | 4.579041 |
| Flight | draw | 600 | 6.794354 | 6.545576 | 7.000500 | 8.277500 | 9.898750 |

## Replica 3

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/final/final-paired-r3.log`

SHA-256: `4e4d11d151e13f4575faac5c120261703866f004555ec4b5ca12e3d3c9246e64`

Esito protocollo: **completo**.

RSS massima del processo: 141.688 MiB (148570112 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.622020 | 9.797838 | 15.217750 | 17.236499 | 18.439876 |
| Still | update | 600 | 0.018375 | 0.019984 | 0.032917 | 0.038250 | 0.043250 |
| Still | draw | 600 | 8.007104 | 8.447267 | 10.003750 | 12.679375 | 12.936042 |
| Walk | frame | 600 | 11.093375 | 12.422724 | 16.886542 | 23.428291 | 27.436208 |
| Walk | update | 600 | 3.257334 | 3.425814 | 4.316875 | 6.743500 | 6.942875 |
| Walk | draw | 600 | 7.052062 | 7.277482 | 8.914708 | 15.228834 | 15.741250 |
| Climb | frame | 600 | 10.971000 | 11.944472 | 15.461708 | 16.409084 | 17.394250 |
| Climb | update | 600 | 3.118479 | 3.127137 | 3.517459 | 3.603958 | 3.708500 |
| Climb | draw | 600 | 7.188354 | 7.085797 | 7.750083 | 8.054917 | 8.337875 |
| Flight | frame | 600 | 10.551354 | 11.175684 | 14.891875 | 15.542833 | 16.369751 |
| Flight | update | 600 | 3.162376 | 3.054304 | 3.344208 | 3.406625 | 3.784750 |
| Flight | draw | 600 | 6.748771 | 6.504728 | 6.954875 | 7.111833 | 8.079875 |
