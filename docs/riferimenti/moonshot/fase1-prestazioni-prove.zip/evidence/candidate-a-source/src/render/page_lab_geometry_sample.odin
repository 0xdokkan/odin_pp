package render

import "core:math"
import rl "vendor:raylib"

// Mask coordinates separate into X and Y. Sample the original source-pixel
// formula at each axis midpoint once, preserving its f32 operations and floor.
// The immutable CPU atlas is acquired once per build, never per sheet cell.
@(private)
Page_Lab_Shape_Samples :: struct {
	origins: [Page_Lab_Surface]rl.Vector3,
	xs: [PAGE_LAB_AXIS_X]f32,
	ys: [PAGE_LAB_AXIS_Y]f32,
	pixel_x: [2][PAGE_LAB_AXIS_X]int,
	pixel_y: [2][PAGE_LAB_AXIS_Y]int,
	masks: [2]^[CARTOON_CELL*CARTOON_CELL]u8,
}

@(private)
page_lab_prepare_shape_samples :: proc(m: ^Page_Lab_Model, samples: ^Page_Lab_Shape_Samples) {
	for surface in Page_Lab_Surface { samples.origins[surface] = page_lab_origin(m.pose, surface) }
	for x in 0..<m.x_count-1 { samples.xs[x] = (m.xs[x]+m.xs[x+1])*.5 }
	for y in 0..<m.y_count-1 { samples.ys[y] = (m.ys[y]+m.ys[y+1])*.5 }
	cache := page_lab_print_cpu()
	for surface, actor in ([2]Page_Lab_Surface{.Hero, .Enemy}) {
		sample := page_lab_print_sample(m.pose, surface, 0)
		samples.masks[actor] = &cache.masks[sample.actor]
		for x in 0..<m.x_count-1 {
			pixel := page_lab_print_source_pixel(sample, {samples.xs[x], 0})
			samples.pixel_x[actor][x] = int(math.floor(pixel.x))
		}
		for y in 0..<m.y_count-1 {
			pixel := page_lab_print_source_pixel(sample, {0, samples.ys[y]})
			samples.pixel_y[actor][y] = int(math.floor(pixel.y))
		}
	}
}

@(private)
page_lab_sampled_mask :: proc(samples: ^Page_Lab_Shape_Samples, actor, x, y: int) -> bool {
	px, py := samples.pixel_x[actor][x], samples.pixel_y[actor][y]
	if px < 0 || py < 0 || px >= CARTOON_CELL || py >= int(CARTOON_FEET) { return false }
	return samples.masks[actor][py*CARTOON_CELL+px] != 0
}

@(private)
page_lab_sampled_surface_at :: proc(samples: ^Page_Lab_Shape_Samples, pose: Page_Lab_Pose, x, y: int) -> Page_Lab_Surface {
	point := rl.Vector2{samples.xs[x], samples.ys[y]}
	for surface in Page_Lab_Surface.Hero..=Page_Lab_Surface.Flight {
		known, covered := false, false
		if surface == .Hero || surface == .Enemy {
			known = true
			covered = page_lab_sampled_mask(samples, int(surface)-int(Page_Lab_Surface.Hero), x, y)
		}
		if page_lab_shape_at(pose, surface, point, samples.origins[surface], known, covered) { return surface }
	}
	return .Page
}
