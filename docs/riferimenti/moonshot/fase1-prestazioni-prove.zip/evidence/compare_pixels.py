#!/usr/bin/env python3
"""Compare decoded native RGBA8 pixels, not PNG compression or metadata."""
import hashlib,json,struct,subprocess,sys
from pathlib import Path
before,after,output=map(Path,sys.argv[1:])
names=sorted(p.name for p in before.glob("odin_pp_page_cardboard_*.png"))
assert len(names)==61
assert names==sorted(p.name for p in after.glob("odin_pp_page_cardboard_*.png"))
results=[]
for name in names:
    images=[]
    for folder in (before,after):
        path=folder/name
        dimensions=struct.unpack(">II",path.read_bytes()[16:24])
        pixels=subprocess.run(["/opt/homebrew/bin/ffmpeg","-v","error","-i",str(path),"-frames:v","1","-pix_fmt","rgba","-f","rawvideo","-"],check=True,stdout=subprocess.PIPE).stdout
        assert len(pixels)==dimensions[0]*dimensions[1]*4
        images.append((dimensions,pixels))
    assert images[0][0]==images[1][0]
    a,b=images[0][1],images[1][1]
    row=dict(name=name,dimensions=images[0][0],before_sha256=hashlib.sha256(a).hexdigest(),after_sha256=hashlib.sha256(b).hexdigest(),identical=a==b)
    if a!=b:
        different=[i//4 for i in range(0,len(a),4) if a[i:i+4]!=b[i:i+4]]
        width=images[0][0][0]
        row.update(different_pixels=len(different),max_channel_delta=max(abs(x-y) for x,y in zip(a,b)),bounds=[min(i%width for i in different),min(i//width for i in different),max(i%width for i in different),max(i//width for i in different)])
    results.append(row)
output.write_text(json.dumps(dict(format="RGBA8",before=str(before),after=str(after),identical=sum(r["identical"] for r in results),count=len(results),images=results),indent=2)+"\n")
print(f"Pixels identical: {sum(r['identical'] for r in results)}/{len(results)}")
for row in results:
    if not row['identical']: print(row)
