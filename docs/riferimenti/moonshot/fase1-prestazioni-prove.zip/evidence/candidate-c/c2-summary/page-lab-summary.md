# Laboratorio pagina: misure verificate

Ogni replica valida contiene quattro atti, ciascuno con 60 frame di riscaldamento esclusi e 600 misurati. Mediana e percentili sono calcolati sui singoli campioni di ciascun atto; p95/p99 usano il rango superiore (nearest rank).

I tempi sono in millisecondi. Frame è il tempo del fotogramma raylib; update e draw sono misure CPU interne al frame. Gli scope sono annidati e non sommabili. Draw misura la preparazione/invio dei comandi, non un timer GPU.

La completezza riguarda il protocollo presente nel log, non certifica l'exit code del processo, l'ottimizzazione della build o il sistema usato. Le repliche incomplete restano elencate e non contribuiscono a statistiche.

## Replica 1

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/candidate-c/c2-r1.log`

SHA-256: `16680e868adb3b0825ede46dc79c6e7b92e4e270d3e05d51321ee9f3cd1cbe83`

Esito protocollo: **completo**.

RSS massima del processo: 140.094 MiB (146898944 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.628813 | 9.571386 | 14.391417 | 16.704667 | 18.436959 |
| Still | update | 600 | 0.019041 | 0.020488 | 0.031667 | 0.037458 | 0.041833 |
| Still | draw | 600 | 8.053062 | 8.327763 | 9.913458 | 12.603125 | 12.728417 |
| Walk | frame | 600 | 10.547625 | 11.428912 | 15.025834 | 16.201042 | 16.933167 |
| Walk | update | 600 | 2.432583 | 2.485544 | 2.816292 | 3.025917 | 3.106708 |
| Walk | draw | 600 | 7.203979 | 7.262660 | 8.366625 | 8.769209 | 8.976333 |
| Climb | frame | 600 | 11.043083 | 11.907240 | 16.309749 | 17.350834 | 18.155709 |
| Climb | update | 600 | 2.368313 | 2.436252 | 2.990167 | 3.558417 | 3.783292 |
| Climb | draw | 600 | 7.369167 | 7.678137 | 9.623667 | 11.137792 | 11.920042 |
| Flight | frame | 600 | 9.806458 | 10.893474 | 14.791333 | 16.320791 | 16.818374 |
| Flight | update | 600 | 2.314292 | 2.338623 | 2.731750 | 2.860167 | 2.900416 |
| Flight | draw | 600 | 6.930896 | 6.942941 | 8.136334 | 8.267291 | 8.386959 |

## Replica 2

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/candidate-c/c2-r2.log`

SHA-256: `84d3d1e9b2680fa922f4e5ea9b1e005af7d8881ccd1692ae91a651219426d21e`

Esito protocollo: **completo**.

RSS massima del processo: 138.203 MiB (144916480 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.668229 | 9.757566 | 14.681417 | 16.476333 | 18.236624 |
| Still | update | 600 | 0.018937 | 0.020624 | 0.032834 | 0.037334 | 0.041000 |
| Still | draw | 600 | 8.086771 | 8.486085 | 10.024542 | 12.536500 | 12.739542 |
| Walk | frame | 600 | 9.258187 | 10.389382 | 15.352417 | 19.368749 | 22.529125 |
| Walk | update | 600 | 2.211646 | 2.298953 | 2.887500 | 4.678166 | 4.762000 |
| Walk | draw | 600 | 6.484333 | 6.858770 | 8.547250 | 13.806542 | 14.044292 |
| Climb | frame | 600 | 9.334438 | 9.934620 | 14.084000 | 15.073166 | 15.931750 |
| Climb | update | 600 | 2.102167 | 2.077159 | 2.300375 | 2.379667 | 2.472917 |
| Climb | draw | 600 | 6.634084 | 6.656547 | 7.268667 | 7.346875 | 7.419375 |
| Flight | frame | 600 | 8.390813 | 9.163917 | 13.474125 | 14.985166 | 15.789000 |
| Flight | update | 600 | 1.966500 | 2.049373 | 2.326166 | 2.395625 | 2.495042 |
| Flight | draw | 600 | 5.966500 | 6.208528 | 6.935792 | 7.020959 | 7.143792 |

## Replica 3

Log: `/Users/dokkan/Dev/odin_pp/build/moonshot/cardboard-performance/candidate-c/c2-r3.log`

SHA-256: `f9f0758d09cf69ef06b899dfe9c98dbaadaf48b42da79ac7f088c5ee177fe9cf`

Esito protocollo: **completo**.

RSS massima del processo: 140.406 MiB (147226624 byte), da `/usr/bin/time -l`; non è memoria esclusiva del modello.

Canvas logico e raster: 1920×1080. Risorse GPU possedute dal laboratorio: uno shader, zero mesh; le risorse condivise di host/raylib sono escluse dal conteggio.

Atlas della stampa: una texture, 4672512 byte dichiarati costanti. Il contatore cumulativo print_uploads resta 1 ai checkpoint dopo 660, 1320, 1980 e 2640 frame (oltre i primi 13): nessun nuovo caricamento segnalato. Il log non contiene un checksum dei pixel.

| Atto | Scope | Campioni | Mediana | Media | p95 | p99 | Massimo |
|---|---|---:|---:|---:|---:|---:|---:|
| Still | frame | 600 | 8.629979 | 9.671448 | 14.581459 | 16.155917 | 17.958708 |
| Still | update | 600 | 0.018354 | 0.020115 | 0.032584 | 0.040333 | 0.073667 |
| Still | draw | 600 | 8.063166 | 8.432505 | 9.964041 | 12.584458 | 12.978208 |
| Walk | frame | 600 | 11.085667 | 11.804058 | 15.930958 | 16.769541 | 18.317999 |
| Walk | update | 600 | 2.506271 | 2.550225 | 2.941416 | 3.155417 | 3.256000 |
| Walk | draw | 600 | 7.318396 | 7.504537 | 8.542125 | 9.286416 | 9.917291 |
| Climb | frame | 600 | 11.318396 | 11.734142 | 15.985001 | 16.717751 | 17.213250 |
| Climb | update | 600 | 2.365854 | 2.403247 | 2.692667 | 2.830500 | 3.115667 |
| Climb | draw | 600 | 7.541937 | 7.630714 | 8.491875 | 8.660500 | 9.564084 |
| Flight | frame | 600 | 9.796604 | 10.959433 | 14.561083 | 15.876999 | 16.682917 |
| Flight | update | 600 | 2.307062 | 2.332147 | 2.697292 | 2.821000 | 2.864542 |
| Flight | draw | 600 | 6.932521 | 6.959272 | 8.067667 | 8.153917 | 8.210458 |
