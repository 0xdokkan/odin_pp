#!/usr/bin/env python3
import json,statistics
from pathlib import Path
root=Path("build/moonshot/cardboard-performance")
variants={v:json.loads((root/("candidate-c" if v=="final" else "before")/"c2-summary/page-lab-summary.json").read_text()) for v in ("before","final")}
rows=[]
for i,act in enumerate(("Still","Walk","Climb","Flight")):
    row={"act":act}
    for v,data in variants.items():
        assert len(data["runs"])==3 and all(r["complete"] for r in data["runs"])
        stages=[r["stages"][i] for r in data["runs"]]
        row[v]={scope:{key:[s["scopes"][scope][key] for s in stages] for key in ("median_ms","mean_ms","p95_ms","p99_ms","max_ms")} for scope in ("frame","update","draw")}
        row[v]["reported"]=stages[0]["reported"]
    rows.append(row)
result=dict(rows=rows,final_p95_budget_ms=16.7,all_final_p95_within_budget=all(x<=16.7 for row in rows for x in row["final"]["frame"]["p95_ms"]),rss={v:[r["process_peak_rss_bytes"] for r in d["runs"]] for v,d in variants.items()})
(root/"comparison-c2.json").write_text(json.dumps(result,indent=2)+"\n")
for row in rows:
    print(row["act"],"p95 prima",row["before"]["frame"]["p95_ms"],"p95 finale",row["final"]["frame"]["p95_ms"])
    print("mediane CPU", {v:{s:row[v][s]["median_ms"] for s in ("update","draw")} for v in ("before","final")})
print("BUDGET",result["all_final_p95_within_budget"],"RSS",result["rss"])
