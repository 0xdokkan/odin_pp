package game

import "core:testing"

@(test)
test_tactical_card_catalog_has_bounded_nonzero_time_costs :: proc(t: ^testing.T) {
	for index in 0..<int(Card_Id.Count) {
		id := Card_Id(index)
		definition, found := card_definition_by_id(id)
		testing.expect(t, found)
		cost := tactical_card_time_cost(id)
		// Movimento Ombra stands outside the window: its four seconds freeze
		// the world instead of spending it. The Canna da Pesca fishes a
		// cleared room, which has no window. The First Person Shooter's and
		// First Person Brawler's seconds run with the world's. Benvenuti a Napoli
		// opens the club's view on one face only: its d4 is cast as the
		// Dinosauro's, and the Lanciafiamme stays on the board: a card like the others.
		if id == .Shadow_Step || id == .Fishing_Rod || (card_is_first_person(id) && id != .Napoli && id != .Flamethrower) { testing.expect_value(t, cost, f32(0)); continue }
		testing.expect(t, cost >= 1 && cost <= 4, definition.name)
	}
	testing.expect_value(t, tactical_card_time_cost(.Count), f32(0))
	testing.expect_value(t, tactical_card_time_cost(.Shadow_Step), f32(0))
	// Creating zero-energy Spark cards must not create zero-time actions.
	testing.expect_value(t, tactical_card_time_cost(.Spark), f32(1))
	testing.expect(t, tactical_card_time_cost(.Guard) < tactical_card_time_cost(.Strike))
	testing.expect(t, tactical_card_time_cost(.Heavy_Blow) < tactical_card_time_cost(.Firebomb))
}
