package game

import grid "../engine/grid"

tactical_dodge_ready :: proc(room: ^Room) -> bool {
	if room == nil || room.player == nil || room.phase != .Combat { return false }
	_, afterimage := status_for_entity(room, PLAYER_ENTITY, .Afterimage)
	return room.player.tactical.dodge_recovery == 0 || afterimage
}

tactical_dodge_has_landing :: proc(room: ^Room) -> bool {
	for direction in Move_Direction {
		query := query_entity_movement(room, PLAYER_ENTITY, add_position(room.player.position, direction_offset(direction)))
		if movement_query_is_clear(&query) { return true }
	}
	return false
}

@(private)
start_tactical_dodge_recovery :: proc(room: ^Room) {
	// Pay the dodge's second, then leave two whole world seconds of recovery.
	// Window recovery beats count; opening/closing UI does not.
	room.player.tactical.dodge_recovery = TACTICAL_DODGE_RECOVERY+1
}

tactical_dodge_destination :: proc(room: ^Room, direction: Move_Direction) -> (destination: grid.Position, ok: bool) {
	if !tactical_dodge_ready(room) { return }
	step := direction_offset(direction)
	origin := room.player.position
	before := origin
	// A short roll is still possible when only the first cell is free.
	for distance in 1..=2 {
		query := query_entity_movement(room, PLAYER_ENTITY, grid.offset(origin, step.x*distance, step.y*distance))
		// The cell the roll lands on, on whichever layer (layers.odin).
		next := query.destination
		if !movement_query_is_clear(&query) || step_height_blocked(room, before, next) { break }
		destination, ok, before = next, true, next
	}
	return
}

try_dodge_player :: proc(room: ^Room, direction: Move_Direction) -> bool {
	// A dodge may cut the player's own timed action short.
	if !tactical_dodge_ready(room) || !tactical_allows_action(room, true) { return false }
	// Never up from the grandpa's table before the meal is over (napoli.odin).
	if napoli_seated(room) { return false }
	destination, clear := tactical_dodge_destination(room, direction)
	if !clear { return false }
	action := make_action(.Move, PLAYER_ENTITY, cell_target(destination), .Walkable_Cell)
	added := add_effect(&action, move_effect(PLAYER_ENTITY, destination))
	assert(added)
	report := resolve_action(room, &action)
	if !report.accepted { return false }
	clear_event_log(room.recent_events)
	append_event_log(room.recent_events, &report.events)
	start_tactical_dodge_recovery(room)
	room.player.tactical.facing = direction
	collect_loot_in_magnet_range(room)
	finish_player_combat_command(room, TACTICAL_DODGE_SECONDS)
	return true
}
