package expedition

import "core:math"
import grid "../engine/grid"
import game "../game"

// Exploration walks continuously; encounters keep their cell steps. The cell
// under the explorer's center stays the room's authoritative position, so
// every rule written for cells (sites, traps, lava, patrols, engagement)
// still reads the same grid while the body glides between cell centers.
ROAM_RADIUS :: f32(0.3)
// On foot half again as quick as the first 3.6 (the user's choice, 2026-10-30),
// still under the mount.
ROAM_WALK_SPEED :: f32(5.4)
ROAM_MOUNT_SPEED :: f32(8.4)
// A substep never crosses more than one cell edge per axis, and stays below
// the radius, so the center can never tunnel into a blocker.
ROAM_MAX_STEP :: f32(0.2)
// How the walk answers the keys on foot (the user's choice, 2026-10-30: more
// alive): it reaches its speed briskly (ACCEL, a share of the gap a second),
// turns about harder (TURN, when the wish points against the walk), and stops
// with a short slide (STOP, about 0.4 cells from full speed).
ROAM_ACCEL :: f32(20)
ROAM_TURN :: f32(34)
ROAM_STOP :: f32(13)
// Sliding past a corner: walking along an axis into the corner of a solid
// cell beside an open way, the walker is eased sideways toward the open
// cell's middle (cells a second, from up to EDGE off it) instead of stopping.
ROAM_CORNER_SPEED :: f32(3)
ROAM_CORNER_EDGE :: f32(0.45)

Roam :: struct {
	// Cell units: cell (x,y) spans [x,x+1)×[y,y+1); its center is +0.5.
	position, velocity: [2]f32,
	// Presentation-only: eases out a relocation forced by gravity or wind.
	offset: [2]f32,
	cell: grid.Position,
	// Distance walked, for the gait of the robot and its mount.
	stride: f32,
	ready: bool,
}

roam_center :: proc(cell:grid.Position)->[2]f32 {return {f32(cell.x)+.5,f32(cell.y)+.5}}
roam_cell :: proc(p:[2]f32)->grid.Position {return {x = int(math.floor(p.x)), y = int(math.floor(p.y))}}

// Gravity wells, wind, tunnels, encounters and saves move the room's player
// directly. The walker adopts that cell instead of overriding it.
roam_sync :: proc(r:^Roam,room:^game.Room) {
	if r==nil || room==nil || room.player==nil {return}
	cell:=room.player.position
	if r.ready && cell==r.cell {return}
	target:=roam_center(cell)
	// A short shove glides; a tunnel or a restored save simply arrives.
	jump:=r.position+r.offset-target
	r.offset={}
	if r.ready && abs(jump.x)+abs(jump.y)<4 {r.offset=jump}
	r.position=target;r.velocity={};r.cell=cell;r.ready=true
}

// The cell of column (x, y) the walker meets there: its own, or where steps across the layers from its cell land
// (game.layer_step: a cave's mouth, a bridge's ramp), a column at a time toward it. Without layers, the ground's.
@(private)
roam_layer_cell :: proc(r:^Roam,room:^game.Room,x,y:int)->grid.Position {
	cell:=r.cell
	for cell.x!=x || cell.y!=y {
		cell,_=game.layer_step(room,cell,{x = clamp(x-cell.x,-1,1), y = clamp(y-cell.y,-1,1)})
	}
	return cell
}

// The cell the walker stands in never blocks it: a light bridge may close
// beneath the robot, and it can still step off. A cell more than a step higher or lower than the one
// it stands in is a cliff, a wall to a walker (game/height.odin), whether on foot or in the saddle.
@(private)
roam_blocked :: proc(r:^Roam,room:^game.Room,cell:grid.Position)->bool {
	return cell!=r.cell && (game.cell_blocks_movement(room,cell) || game.step_height_blocked(room,r.cell,cell))
}

// Circle against solid cells. A corner shared with a neighbouring solid cell
// is an inner seam of a flat wall: it pushes along the wall's face, never
// against the walk, so sliding along long walls does not catch at the seams.
@(private)
roam_resolve :: proc(r:^Roam,room:^game.Room) {
	for _ in 0..<3 {
		pushed:=false
		base:=roam_cell(r.position)
		for dy in -1..=1 {for dx in -1..=1 {
			cell:=roam_layer_cell(r,room,base.x+dx,base.y+dy)
			if !roam_blocked(r,room,cell) {continue}
			lo:=[2]f32{f32(cell.x),f32(cell.y)};hi:=lo+1
			closest:=[2]f32{clamp(r.position.x,lo.x,hi.x),clamp(r.position.y,lo.y,hi.y)}
			d:=r.position-closest;length:=math.sqrt(d.x*d.x+d.y*d.y)
			if length>=ROAM_RADIUS {continue}
			normal:[2]f32;depth:f32
			if length<1e-5 {
				// Only reachable after an external relocation: leave by the nearest face.
				faces:=[4]f32{r.position.x-lo.x,hi.x-r.position.x,r.position.y-lo.y,hi.y-r.position.y}
				normals:=[4][2]f32{{-1,0},{1,0},{0,-1},{0,1}}
				side:=0;for f,i in faces {if f<faces[side] {side=i}}
				normal=normals[side];depth=faces[side]+ROAM_RADIUS
			} else {
				normal=d/length;depth=ROAM_RADIUS-length
				if d.x!=0 && d.y!=0 {
					sx,sy:=int(math.sign(d.x)),int(math.sign(d.y))
					along_x:=roam_blocked(r,room,roam_layer_cell(r,room,cell.x+sx,cell.y))
					along_y:=roam_blocked(r,room,roam_layer_cell(r,room,cell.x,cell.y+sy))
					if along_x && along_y {continue}
					if along_x {normal={0,f32(sy)};depth=ROAM_RADIUS-abs(d.y)}
					else if along_y {normal={f32(sx),0};depth=ROAM_RADIUS-abs(d.x)}
				}
			}
			if depth<=0 {continue}
			r.position+=normal*depth;pushed=true
			into:=r.velocity.x*normal.x+r.velocity.y*normal.y
			if into<0 {r.velocity-=normal*into}
		}}
		if !pushed {break}
	}
}

// Entering a cell uses the exact trap and hazard pipeline of a grid step. A lift's landing with its platform there takes
// the walker to its other end (game/lift.odin): it adopts the cell it rides to.
@(private)
roam_enter :: proc(w:^World,room:^game.Room,r:^Roam,cell:grid.Position)->bool {
	r.cell=cell;room.player.position=cell
	if game.lift_board(room,game.PLAYER_ENTITY,cell) {r.velocity={};roam_sync(r,room);return false}
	before:=room.player.health
	game.expedition_enter_cell(room)
	if room.player.health<before {w.mounted=false}
	if room.player.health<=0 {room.phase=.Defeat;r.velocity={};return false}
	if room.player.position!=cell || room.phase!=.Loot {r.velocity={};roam_sync(r,room);return false}
	return true
}

// The walker pressing on the face of the cell toward `direction` (the wish, of length one at most), along each axis it
// presses: against a lift's landing its platform is away from it calls the platform, against a gate's bars from the
// gate's lever it opens the gate (game/lift.odin), as a step does.
@(private)
roam_press :: proc(room:^game.Room,r:^Roam,direction:[2]f32) {
	center:=roam_center(r.cell)
	for axis in 0..<2 {
		if abs(direction[axis])<.5 {continue}
		sign:=1 if direction[axis]>0 else -1
		// Only once it touches the face.
		if (r.position[axis]-center[axis])*f32(sign)<.5-ROAM_RADIUS-.02 {continue}
		step:=grid.Position{x = sign} if axis==0 else grid.Position{y = sign}
		next:=roam_layer_cell(r,room,r.cell.x+step.x,r.cell.y+step.y)
		if !game.lift_call(room,next) {_=game.gate_opens(room,r.cell,next)}
	}
}

// Walking straight along an axis into a corner beside an open way: eased
// toward the open cell's middle (ROAM_CORNER_SPEED), so a doorway or a
// corridor is taken without lining up by hand.
@(private)
roam_round_corner :: proc(room:^game.Room,r:^Roam,direction:[2]f32,dt:f32) {
	axis:=0 if abs(direction.x)>=abs(direction.y) else 1
	other:=1-axis
	// Only a walk mostly along one axis.
	if abs(direction[other])>.35 {return}
	sign:=1 if direction[axis]>0 else -1
	step:=[2]int{sign,0} if axis==0 else [2]int{0,sign}
	ahead:=roam_layer_cell(r,room,r.cell.x+step.x,r.cell.y+step.y)
	if roam_blocked(r,room,ahead) {return}
	center:=roam_center(r.cell)
	off:=r.position[other]-center[other]
	if abs(off)<.02 || abs(off)>ROAM_CORNER_EDGE {return}
	// Close to the face ahead, and the cell beside the open one on this side solid.
	if (r.position[axis]-center[axis])*f32(sign)<.5-ROAM_RADIUS-.12 {return}
	side:=1 if off>0 else -1
	beside:=[2]int{step.x,side} if axis==0 else [2]int{side,step.y}
	if !roam_blocked(r,room,roam_layer_cell(r,room,r.cell.x+beside.x,r.cell.y+beside.y)) {return}
	nudge:=min(abs(off),ROAM_CORNER_SPEED*dt)
	r.position[other]-=f32(side)*nudge
}

roam_speed :: proc(w:^World,ground:Terrain)->f32 {
	speed:=ROAM_MOUNT_SPEED if w.mounted else ROAM_WALK_SPEED
	if ground==.Sand || ground==.Water || ground==.Snow || ground==.Swamp {speed*=.5}
	return speed
}

// `wish` is the walk direction in cells, already turned to the camera; its
// length is clamped to one. Exploration only: encounters own the cell steps.
roam_step :: proc(w:^World,room:^game.Room,r:^Roam,wish:[2]f32,dt:f32) {
	if w==nil || room==nil || room.player==nil || r==nil {return}
	if room.phase!=.Loot {
		// Encounters step by cells: the walker waits at the cell's center.
		r^={position=roam_center(room.player.position),cell=room.player.position,stride=r.stride,ready=true}
		return
	}
	roam_sync(r,room)
	elapsed:=min(max(dt,0),f32(.1))
	r.offset*=math.exp(-12*elapsed)
	if elapsed<=0 {return}
	// On a lift's platform the walker goes nowhere until it stops.
	if game.lift_player_riding(room) {r.velocity={};return}
	under:=ground(w,r.cell)
	direction:=wish;length:=math.sqrt(direction.x*direction.x+direction.y*direction.y)
	if length>1 {direction/=length;length=1}
	// Brisk on foot, weighty in the saddle, slippery on ice; on foot a turn
	// about bites harder, a stop slides a little.
	rate:=f32(4.5) if w.mounted else ROAM_ACCEL
	if !w.mounted && length>=.01 && direction.x*r.velocity.x+direction.y*r.velocity.y<0 {rate=ROAM_TURN}
	if length<.01 {rate=6 if w.mounted else ROAM_STOP}
	if under==.Ice {rate=2.2 if length>=.01 else .7}
	r.velocity+=(direction*roam_speed(w,under)-r.velocity)*(1-math.exp(-rate*elapsed))
	if length>=.5 {roam_round_corner(room,r,direction,elapsed)}
	if length<.01 && r.velocity.x*r.velocity.x+r.velocity.y*r.velocity.y<.0004 {r.velocity={}}
	travel:=r.velocity*elapsed
	steps:=max(1,int(math.ceil(max(abs(travel.x),abs(travel.y))/ROAM_MAX_STEP)))
	start:=r.position
	for _ in 0..<steps {
		r.position+=travel/f32(steps)
		roam_resolve(r,room)
		column:=roam_cell(r.position)
		cell:=roam_layer_cell(r,room,column.x,column.y)
		if cell!=r.cell && !roam_enter(w,room,r,cell) {return}
	}
	moved:=r.position-start
	r.stride+=math.sqrt(moved.x*moved.x+moved.y*moved.y)
	if length>=.5 {roam_press(room,r,direction)}
}
